

# Last update: 2024/11/14

#-----------------------------------------------------------------------------
# General Comments
#-----------------------------------------------------------------------------
puts "  "
puts "  "
puts "  "
puts "  "

#-----------------------------------------------------------------------------
# Main Custom Variables Design Dependent (set local)
#-----------------------------------------------------------------------------
set PROJECT_DIR $env(PROJECT_DIR)
set TECH_DIR $env(TECH_DIR)
set DESIGNS $env(DESIGNS)
set HDL_NAME $env(HDL_NAME)
# set INTERCONNECT_MODE ple


#-----------------------------------------------------------------------------
# MAIN Custom Variables to be used in SDC (constraints file)
#-----------------------------------------------------------------------------
# set MAIN_CLOCK_NAME clk
# set MAIN_RST_NAME rst
# set BEST_LIB_OPERATING_CONDITION PVT_1P32V_0C
# set WORST_LIB_OPERATING_CONDITION PVT_0P9V_125C
# set period_clk 100.0  ;#clk = 10.00 MHz = 100 s (period)
# set clk_uncertainty 0.25 ;# ns (“a guess”)
# set clk_latency 0.35 ;# ns (“a guess”)
# set in_delay 1 ;# ns
# set out_delay 2.958 ;#ns 
# set out_load 0.045 ;#pF 
# set slew "146 164 264 252" ;#minimum rise, minimum fall, maximum rise and maximum fall 
# set slew_min_rise 0.146 ;# ns
# set slew_min_fall 0.164 ;# ns
# set slew_max_rise 0.264 ;# ns
# set slew_max_fall 0.252 ;# ns
#
set WORST_LIST {slow_vdd1v0_basicCells.lib} 
set BEST_LIST {fast_vdd1v2_basicCells.lib} 
set LEF_LIST {gsclib045_tech.lef gsclib045_macro.lef}
set WORST_CAP_LIST ${TECH_DIR}/gpdk045_v_6_0/soce/gpdk045.basic.CapTbl
set QRC_LIST ${TECH_DIR}/gpdk045_v_6_0/qrc/rcworst/qrcTechFile



#-----------------------------------------------------------------------------
# Load Path File
#-----------------------------------------------------------------------------
source ${PROJECT_DIR}/backend/synthesis/scripts/common/path.tcl
puts $LIB_DIR



#-----------------------------------------------------------------------------
# Set LIB_SRC directory
#-----------------------------------------------------------------------------
set LIB_SRC ${LIB_DIR}/../verilog/


#-----------------------------------------------------------------------------
# Modus: Build Model
#-----------------------------------------------------------------------------
build_model -workdir ${PROJECT_DIR}/backend/synthesis/work \
            -designsource ${PROJECT_DIR}/backend/synthesis/work/test_scripts/${HDL_NAME}.test_netlist.v \
            -techlib ${LIB_SRC}/slow_vdd1v0_basicCells.v -designtop ${HDL_NAME}

#-----------------------------------------------------------------------------
# Modus: Test Mode
#-----------------------------------------------------------------------------
build_testmode -workdir ${PROJECT_DIR}/backend/synthesis/work \
               -testmode FULLSCAN \
               -assignfile ${PROJECT_DIR}/backend/synthesis/work/test_scripts/${HDL_NAME}.FULLSCAN.pinassign


#-----------------------------------------------------------------------------
# Modus: Verify Test Structures
#-----------------------------------------------------------------------------
verify_test_structures -workdir ${PROJECT_DIR}/backend/synthesis/work \
                       -testmode FULLSCAN
                       

#-----------------------------------------------------------------------------
# Modus: Report Test Structures
#-----------------------------------------------------------------------------
report_test_structures -workdir ${PROJECT_DIR}/backend/synthesis/work \
                       -testmode FULLSCAN



#-----------------------------------------------------------------------------
# Modus: Build Fault Model
#-----------------------------------------------------------------------------
build_faultmodel -workdir ${PROJECT_DIR}/backend/synthesis/work \
                 -fullfault yes


#-----------------------------------------------------------------------------
# Modus: Create Scan Test
#-----------------------------------------------------------------------------
create_scanchain_tests -workdir ${PROJECT_DIR}/backend/synthesis/work \
                       -testmode FULLSCAN -experiment SCAN


#-----------------------------------------------------------------------------
# Modus: Create Logic Test
#-----------------------------------------------------------------------------
create_logic_tests -workdir ${PROJECT_DIR}/backend/synthesis/work \
                   -testmode FULLSCAN \
                   -experiment logic -effort high



write_vectors -workdir ${PROJECT_DIR}/backend/synthesis/work \
              -testmode FULLSCAN -inexperiment logic -language verilog \
              -scanformat serial -outputfilename ${HDL_NAME}_test_results


# exit
#-----------------------------------------------------------------------------
# Load Tech File
#-----------------------------------------------------------------------------
# source ${SCRIPT_DIR}/common/tech.tcl
# set_db [get_db library_domain *best] .default true

#-----------------------------------------------------------------------------
# Analyze RTL source (manually set; file_list.tcl is not covered in ELC1054)
#-----------------------------------------------------------------------------
# set_db init_hdl_search_path "${DEV_DIR} ${FRONTEND_DIR}"
# set rtl_files ${DESIGNS}.vhd
# puts "Analyzing RTL source files: $HDL_NAME"
# read_hdl -language vhdl $rtl_files

#-----------------------------------------------------------------------------
# Elaborate Design
#-----------------------------------------------------------------------------
# elaborate ${HDL_NAME}
# set_top_module ${HDL_NAME}
# check_design -unresolved ${HDL_NAME}
# get_db current_design
# check_library

#-----------------------------------------------------------------------------
# Constraints
#-----------------------------------------------------------------------------
# read_sdc ${BACKEND_DIR}/synthesis/constraints/${HDL_NAME}.sdc
# report timing -lint
# gui_show

#-----------------------------------------------------------------------------
# Load DFT Rules
#-----------------------------------------------------------------------------
# set_db dft_scan_style muxed_scan
# set_db dft_prefix dft_
# define_shift_enable -name SE -active high -create_port SE
# check_dft_rules

#-----------------------------------------------------------------------------
# Pos "Elaborate" Attributes (manually set)
#-----------------------------------------------------------------------------
# set_db auto_ungroup none ;# (none|both) ungrouping will not be performed

#-----------------------------------------------------------------------------
# Generic optimization (technology independent)
#-----------------------------------------------------------------------------
# syn_generic ${HDL_NAME} 

#-----------------------------------------------------------------------------
# Agressively optimization (area, timing, power) and mapping
#-----------------------------------------------------------------------------
# syn_map ${HDL_NAME} 
# get_db insts .base_cell.name -u ;# List all cell names used in the current design.

#-----------------------------------------------------------------------------
# DFT SynOpt rules
#-----------------------------------------------------------------------------
# check_dft_rules
# set_db design:sequential .dft_min_number_of_scan_chains 1
# define_scan_chain -name top_chain -sdi scan_in -sdo scan_out -create_ports
# connect_scan_chains -auto_create_chains
# syn_opt -incr
# report_scan_chains

#-----------------------------------------------------------------------------
# Preparing and generating output data (reports, verilog netlist)
#-----------------------------------------------------------------------------
# report_design_rules ;# > ${RPT_DIR}/${HDL_NAME}_drc.rpt
# report_area > ${RPT_DIR}/${HDL_NAME}_area.rpt
# report_timing > ${RPT_DIR}/${HDL_NAME}_timing.rpt
# report_gates > ${RPT_DIR}/${HDL_NAME}_gates.rpt
# report_qor > ${RPT_DIR}/${HDL_NAME}_qor.rpt
# report_power > ${RPT_DIR}/${HDL_NAME}_power.rpt

# write_sdf -edge check_edge -setuphold merge_always -nonegchecks -recrem split -version 3.0 -design ${HDL_NAME} > ${DEV_DIR}/${HDL_NAME}_worst.sdf
# write_hdl ${HDL_NAME} > ${DEV_DIR}/${HDL_NAME}.v
# write_scandef > ${DEV_DIR}/${HDL_NAME}.scandef




