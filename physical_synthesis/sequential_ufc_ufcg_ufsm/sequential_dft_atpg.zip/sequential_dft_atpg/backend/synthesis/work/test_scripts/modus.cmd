# Cadence Modus
#   Cadence(R) Modus(TM) DFT Software Solution, Version 22.12-s028_1, built Jul 11 2023 (linux26_64)
#   Date: Friday, March 14, 2025
source runmodus.atpg.tcl
msgHelp TDA-009
build_model \    -cell sequential \    -techlib  /home/tools/cadence/gpdk/gsclib045_svt_v4.4/lan/flow/t1u1/reference_libs/GPDK045/gsclib045_svt_v4.4/gsclib045/timing/../verilog//slow_vdd1v0_basicCells.v \    -designsource  $WORKDIR/sequential.test_netlist.v \    -allowmissingmodules  no \    -messagecounteach 100 \

\
