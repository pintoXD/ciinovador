#SPRAM256X8.v file must be in the same folder as the others system verilog files.
xrun -64bit ram_writer_tb.sv ram_writer.sv SPRAM256X8.v +gui +access+rw